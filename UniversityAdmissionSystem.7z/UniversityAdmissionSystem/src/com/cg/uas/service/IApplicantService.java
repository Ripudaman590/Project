package com.cg.uas.service;

import java.util.ArrayList;

import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;

public interface IApplicantService 
{


	public int addApplicant(Application app) throws ApplicationException;

	public int generateAppId() throws ApplicationException;
	
	public Application viewApplication(int applicationid);
	
	public ArrayList<Application> getAllApplications();
}