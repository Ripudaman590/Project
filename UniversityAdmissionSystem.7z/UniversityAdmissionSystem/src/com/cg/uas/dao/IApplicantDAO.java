package com.cg.uas.dao;

import java.util.ArrayList;

import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;

public interface IApplicantDAO 
{

	public int addApplicant(Application app) throws ApplicationException;

	public int generateAppId() throws ApplicationException;
	
	public Application viewApplication(int applicationid);
	
	public ArrayList<Application> getAllApplications();
}
