package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;



import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;
import com.cg.uas.util.DbUtil;

public class ApplicantDAOImpl implements IApplicantDAO
{
	
	Connection conn = null;
	PreparedStatement pstm = null;
	private static final String query= "Insert into application values(?,?,?,?,?,?,?,?,?,?)";
	private static final String APPID_query = "SELECT SEQ_APPID.NEXTVAL FROM DUAL";
	
	@Override
	public int addApplicant(Application app) throws ApplicationException
	{
		int status = 0;
		int applicationId = generateAppId();
		app.setApplicationId(applicationId);
		System.out.println(applicationId);
		try {
			conn=DbUtil.getConnection();
			pstm=conn.prepareStatement(query);
			
			pstm.setInt(1, applicationId);
			pstm.setString(2, app.getFullName());
			pstm.setDate(3, app.getDob());
			pstm.setString(4, app.getHighestQual());
			pstm.setDouble(5, app.getMarks());
			pstm.setString(6, app.getGoals());
			pstm.setString(7, app.getEmailId());
			pstm.setString(8, app.getScheduledProgramId());
			pstm.setString(9, app.getStatus());
			pstm.setDate(10, (Date) app.getDoi());
	
			status=pstm.executeUpdate();
			
			if (status == 0) 
			{
			
				throw new ApplicationException("Problem In Insertion");
			}
		} 
		catch (NamingException | SQLException e) 
		{
			
			e.printStackTrace();
			throw new ApplicationException(e.getMessage());
		}
		
		finally 
		{
			try {
				if (conn != null) 
				{

					pstm.close();
					conn.close();
				}
			}
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}


		}


		return applicationId;

	}

	@Override
	public int generateAppId() throws ApplicationException
	{
		int appId = 0;
		try 
		{
			conn = DbUtil.getConnection();
			pstm = conn.prepareStatement(APPID_query);
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next())
			{
				appId = rs.getInt(1);
			}
			
			
		}
		
		catch (NamingException e) 
		{
			
			e.printStackTrace();
		}
		
		catch (SQLException e) 
		{
		
			e.printStackTrace();
		}
		return appId;
		
	}

	@Override
	public Application viewApplication(int applicationid) 
	{
		Application app = null;
	
		System.out.println("daoooooooooooooooo");
		try {
			conn = DbUtil.getConnection();
			String query1= "select * from application where application_id=?";
			pstm = conn.prepareStatement(query1);
			pstm.setInt(1, applicationid);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) 
			{
			
				app = new Application();
				app.setFullName(rs.getString("full_name"));
				app.setDob(rs.getDate("date_of_birth"));
				app.setHighestQual(rs.getString("highest_qualification"));
				app.setMarks(rs.getDouble("marks_obtained"));
				app.setGoals(rs.getString("goals"));
				app.setEmailId(rs.getString("email_id"));
				app.setScheduledProgramId(rs.getString("scheduled_program_id"));
				app.setStatus(rs.getString("status"));
				app.setDoi(rs.getDate("date_of_interview"));
				
			}
		} 
		catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return app;
	}

	@Override
	public ArrayList<Application> getAllApplications()
	{
		ArrayList<Application> appList = null ;
		try 
		{
			System.out.println("daoo aagyaa");
			appList =  new ArrayList<>();
			conn = DbUtil.getConnection();
			String query2 = "select * from application";
			pstm = conn.prepareStatement(query2);
			ResultSet rs = pstm.executeQuery();
			
			Application app = null;
			while(rs.next())
			{
				app = new Application();
				app.setApplicationId(rs.getInt(1));
				app.setFullName(rs.getString(2));
				app.setDob(rs.getDate(3));
				app.setHighestQual(rs.getString(4));
				app.setMarks(rs.getDouble(5));
				app.setGoals(rs.getString(6));
				app.setEmailId(rs.getString(7));
				app.setScheduledProgramId(rs.getString(8));
				app.setStatus(rs.getString(9));
				app.setDoi(rs.getDate(10));
				
				appList.add(app);
			}
		}
		catch (NamingException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return appList;
	}

}
