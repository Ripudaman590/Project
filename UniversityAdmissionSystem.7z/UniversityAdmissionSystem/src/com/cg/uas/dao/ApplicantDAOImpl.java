package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;


import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;
import com.cg.uas.util.DbUtil;

public class ApplicantDAOImpl implements IApplicantDAO
{
	
	Connection conn = null;
	PreparedStatement pstm = null;
	private static final String query= "Insert into application values(?,?,?,?,?,?,?,?,?)";
	private static final String APPID_query = "SELECT SEQ_APPID.NEXTVAL FROM DUAL";
	
	@Override
	public int addApplicant(Application app) throws ApplicationException
	{
		int status = 0;
		
		try {
			conn=DbUtil.getConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1, app.getFullName());
			pstm.setDate(2, (Date) app.getDob());
			pstm.setString(3, app.getHighestQual());
			pstm.setDouble(4, app.getMarks());
			pstm.setString(5, app.getGoals());
			pstm.setString(6, app.getEmailId());
			pstm.setString(7, app.getScheduledProgramId());
			pstm.setString(8, app.getStatus());
			pstm.setDate(9, (Date) app.getDoi());
			
			status=pstm.executeUpdate();
			
			if (status == 0) 
			{
			
				throw new ApplicationException("Problem In Insertion");
			}
		} 
		catch (NamingException | SQLException e) 
		{
			
			e.printStackTrace();
			throw new ApplicationException(e.getMessage());
		}
		
		finally 
		{
			try {
				if (conn != null) 
				{

					pstm.close();
					conn.close();
				}
			}
			catch (SQLException e) 
			{
				
				e.printStackTrace();
			}


		}


		return status;

	}

	@Override
	public int generateAppId() throws ApplicationException
	{
		int appId = 0;
		try 
		{
			conn = DbUtil.getConnection();
			pstm = conn.prepareStatement(APPID_query);
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next())
			{
				appId = rs.getInt(1);
			}
			
			
		}
		
		catch (NamingException e) 
		{
			
			e.printStackTrace();
		}
		
		catch (SQLException e) 
		{
		
			e.printStackTrace();
		}
		return appId;
		
	}

}
