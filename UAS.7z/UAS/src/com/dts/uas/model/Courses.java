package com.dts.uas.model;

public class Courses {
	private String collegename;
	private String university;
	private String courses;
	private String noofseats;
	private String bcseats;
	private String scseats;
	private String branch;
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getCollegename() {
		return collegename;
	}
	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public String getCourses() {
		return courses;
	}
	public void setCourses(String courses) {
		this.courses = courses;
	}
	public String getNoofseats() {
		return noofseats;
	}
	public void setNoofseats(String noofseats) {
		this.noofseats = noofseats;
	}
	public String getBcseats() {
		return bcseats;
	}
	public void setBcseats(String bcseats) {
		this.bcseats = bcseats;
	}
	public String getScseats() {
		return scseats;
	}
	public void setScseats(String scseats) {
		this.scseats = scseats;
	}

}
